
console.log("✅ script.js is loaded");

document.getElementById('coffeeForm').addEventListener('submit', function (e) {
  e.preventDefault();
  console.log("🚀 Form submitted");
});
